from django.apps import AppConfig


class UttarConfig(AppConfig):
    name = 'uttar'
